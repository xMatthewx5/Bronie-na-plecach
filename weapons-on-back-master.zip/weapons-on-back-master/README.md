# Weapons On Back

Looking for a framework-independent script to make weapons show up on a player's back if they have it in their weapon wheel? Look no further! This is a great script for RP servers.

<details>
<summary>Screenshot</summary>
<br>

![weaponsonback|690x388](https://i.imgur.com/MkmBlws.jpg)

(notice the cops with weapons on their backs)

</details>

## Features

- Standalone
- Synced across all players
- Easy Install

## Installation

- Download from here.
- Put the ``weapons-on-back`` folder into your server's ``resources`` folder.
- Add ``start weapons-on-back`` to your server's ``server.cfg`` file.
- Enjoy!
